﻿using UnityEngine;
using UnityEditor;
using System.Collections;
//
//[CustomPropertyDrawer(typeof(LoopTrack))]
//public class LoopTrackDrawer : PropertyDrawer {
//
//	public override void OnGUI (Rect position, SerializedProperty property, GUIContent label)
//	{
//
//
//	}
//
//}
