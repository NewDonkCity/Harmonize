# Patapon_Beat_Input_Recreation
Recreating the rhythm based input from the Patapon series
